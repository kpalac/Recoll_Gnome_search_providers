Gnome Search Providers for Recoll search tool. It divides search into Files, Mail, Notes and News. Search scripts query each respective
folders in Home directory. One can link mail box into ~/Mail folder for it to be indexed. ~/Notes and ~/News can be populated by Feedex
or other tools. Pretty simple, but it helped me a lot with large amounts of files, mail and rss news.

Also contains icons and pixmaps from Super Flat Remix theme for look-and-feel, as well as configuration files for Recoll.

INSTALLATION:

    Unpack ZIP
    Run ./install.sh. Use no_deps option to skip installing dependencies and no_icons to skip copying icons if they don't suit your liking 
